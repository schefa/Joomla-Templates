<?php 
/*
 * @version             4.0.0
 * @package             sunshine
 * @author            	Fjodor Schäfer
 * @copyright			Copyright (C) 2015 schefa.com. All rights reserved.
 * @license				Creative Commons Attribution-Share Alike 3.0 Unported
*/
  
// No direct access.
defined('_JEXEC') or die;

class TemplateLayout
{
	
    function getModules($modules = array(), $prefix, $count, $notVisible)
    { 
		$return = '';
		
		if(!empty($modules)) {
			
			if($count > 0) $count	= 12 / $count;
			$return	.= '<div class="sunshine-module-container">';
				$return	.= '<div class="clearfix">';
				foreach($modules AS $key => $value)
	
					if(!in_array($key, $notVisible)) {
						{
							$return .= '<div class="'.$prefix.'-'.	$count	.'">';
							$return .= '<div class="sunshine-module">';
							$return .= '	<div class="'.$value[1].'">';
							$return .= '		<jdoc:include type="modules" name="'.	$key	.'" style="'.	$value[0]	.'" />';
							$return .= '	</div>';
							$return .= '</div>';
							$return .= '</div>';
						}
					}
				$return .= '</div>';
			$return .= '</div>';
			
		}
		
		echo $return;
	}
	
}

?>