<?php 
/*
 * @version             4.0.0
 * @package             sunshine
 * @author            	Fjodor Schäfer
 * @copyright			Copyright (C) 2015 schefa.com. All rights reserved.
 * @license				Creative Commons Attribution-Share Alike 3.0 Unported
*/
 
// No direct access. 
defined('_JEXEC') or die;
 
function modChrome_sidebar( $module, &$params, &$attribs ) {
    if (isset( $attribs['headerLevel'] )) 
    {
      $headerLevel = $attribs['headerLevel'];
    } else {
      $headerLevel = 3;
    }
    echo '<div class="sunshine-module-sidebar' .$params->get( 'moduleclass_sfx' ) .'" >';
 
    if ($module->showtitle) 
    {
      echo '<h' .$headerLevel .'>' .$module->title .'</h' .$headerLevel .'>';
    }
 
    echo '<div class="sunshine-module-inside">';
    echo $module->content;
    echo '</div>';
 
    echo '</div>';
}


?>