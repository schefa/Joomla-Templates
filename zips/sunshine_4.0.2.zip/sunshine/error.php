<?php
/*
 * @version             4.0.0
 * @package             sunshine
 * @author            	Fjodor Schäfer
 * @copyright			Copyright (C) 2015 schefa.com. All rights reserved.
 * @license				Creative Commons Attribution-Share Alike 3.0 Unported
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

if (!isset($this->error)) {
	$this->error = JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
	$this->debug = false;
}

// get template name and parameters
$app = JFactory::getApplication();
$doc = JFactory::getDocument();

// send correct HTTP status code
if ($this->error->getCode() == 404 ) {
	header("HTTP/1.0 404 Not Found");
}


	require_once('lib/framework.php');
	$sunshine = new TemplateLayout;
	
	$content_width = array();
	if($doc->getBuffer('modules', 'left') && $doc->getBuffer('modules', 'right'))
		$content_width = array('3', '6');
	if(($doc->getBuffer('modules', 'left') && !$doc->getBuffer('modules', 'right')) or (!$doc->getBuffer('modules', 'left') && $doc->getBuffer('modules', 'right'))) 
		$content_width = array('3', '9');
	if(!$doc->getBuffer('modules', 'left') && !$doc->getBuffer('modules', 'right'))
		$content_width = array('0', '12');
		
?>
<!doctype html>

<head>
  <title><?php echo $this->error->getCode(); ?> - <?php echo $this->title; ?></title>
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  
  
    <link href="<?php echo JURI::base(); ?>/templates/<?php echo $this->template?>/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo JURI::base(); ?>/templates/<?php echo $this->template?>/css/template.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo JURI::base(); ?>/templates/<?php echo $this->template?>/css/custom.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo JURI::base(); ?>/templates/<?php echo $this->template?>/css/template.blue.css" rel="stylesheet" type="text/css" />
    
    <link rel="shortcut icon" href="<?php echo JURI::base(); ?>/images/favicon.ico" />

    <script>
	function offcanvasToggle() {
		var offcanvas = document.getElementById("offcanvas");
		var middle = document.getElementById("sunshine-background-color");
		if ( offcanvas.style.display == "block" ) {
			offcanvas.style.display = "none";
			middle.className = "";
		} else {
			offcanvas.style.display = "block";
			middle.className = "toggle";
		}
	}
	</script>
</head>

    <body>
    
    <div id="sunshine-background-color">
        
        <div class="container container-center">

            <div id="sunshine-header" class="clearfix">
        
                <?php if($doc->getBuffer('modules', 'social', array('style' => 'none'))) : ?>
                    <div id="social"><?php echo $doc->getBuffer('modules', 'social', array('style' => 'none')); ?></div>
                <?php endif; ?>
                <?php if($doc->getBuffer('modules', 'search', array('style' => 'none'))) : ?>
                <div id="search-container" class="hidden-small">
                    <div id="search" class="form"><?php echo $doc->getBuffer('modules', 'search', array('style' => 'none')); ?></div>
                </div>
                <?php endif; ?>
                    
            </div>

            <div id="sunshine-container">
            
                <nav class="navigation clearfix">
                
                    <div class="visible-small">
						<a class="sunshine-toggle" href="#" onClick="offcanvasToggle()">
                        	<span class="icon-bar"></span>
                        	<span class="icon-bar"></span>
                        	<span class="icon-bar"></span>
                        </a>
						<div class="navbar-brand">
							<?php if($doc->getBuffer('modules', 'search', array('style' => 'none'))) : ?>
                            <div id="search" class="form"><?php echo $doc->getBuffer('modules', 'search', array('style' => 'none')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                
					<div class="hidden-small"><?php echo $doc->getBuffer('modules', 'mainmenu', array('style' => 'ukNavbar')); ?></div>
                </nav>
            
                <div class="clearfix">
                
					<?php if($doc->getBuffer('modules', 'left')) : ?>
                        <div id="left-sidebar" class="col-md-<?php echo $content_width[0]; ?>">
                        	<?php echo $doc->getBuffer('modules', 'left', array('style' => 'sidebar')); ?>
                        </div>
					<?php endif; ?>
                    
                    <div class="col-md-<?php echo $content_width[1]; ?>">
                    
                        <div id="content">
                            <div class="errorboxoutline">
                                <h2 class="errorboxheader"><?php echo $this->error->getCode(); ?> - Uups</h2>
                                <div class="errorboxbody">
                                    <p><strong><?php echo JText::_('JERROR_LAYOUT_NOT_ABLE_TO_VISIT'); ?></strong></p>
                                    <div id="techinfo">
                                    <p><?php echo $this->error->getMessage(); ?></p>
                                    <p>
                                        <?php if ($this->debug) :
                                            echo $this->renderBacktrace();
                                        endif; ?>
                                    </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    
					<?php if($doc->getBuffer('modules', 'right')) : ?>
                        <div id="right-sidebar" class="col-md-<?php echo $content_width[0]; ?>">
                        	<?php echo $doc->getBuffer('modules', 'right', array('style' => 'sidebar')); ?>
                        </div>
					<?php endif; ?>
                    
                </div>
                
                
            </div>
                
            <div id="sunshine-footer">
                <div id="copy">&copy; <?php echo JHTML::Date( 'now', 'Y' ); ?> <?php echo $app->getCfg('sitename'); ?></div>
                <?php 
                /*
                * License: 
                * Creative Commons Attribution-Share Alike 3.0 Unported
                *
                * WARNING: You are not allowed to remove the link to the copyright owner.
                */
                ?>
                <div id="webdesign-by">Design by <a href="http://www.schefa.com" target="_blank">schefa.com</a></div>
            </div>
                
        </div>

        
	</div>
      
    	<div id="offcanvas" style="display:none;">
            <div class="offcanvas-bar">
            	<?php echo $doc->getBuffer('modules', 'mobile', array('style' => 'sidebar')); ?>
            </div>
        </div>
        
    </body>
</html>


