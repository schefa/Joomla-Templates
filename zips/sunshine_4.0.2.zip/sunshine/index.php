<?php
/*
 * @version             4.0.0
 * @package             sunshine
 * @author            	Fjodor Schäfer
 * @copyright			Copyright (C) 2015 schefa.com. All rights reserved.
 * @license				Creative Commons Attribution-Share Alike 3.0 Unported
*/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">

<head>
	<jdoc:include type="head" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <link rel="shortcut icon" href="<?php echo JURI::base(); ?>/templates/sunshine/favicon.ico" />
    
    <?php 	
    $app	= JFactory::getApplication(); 
    $doc	= JFactory::getDocument();
    $view	= $app->input->getCmd('view', '');
        
    require_once('lib/framework.php');
    $sunshine = new TemplateLayout;
        
    $content_width = array();
    if($this->countModules('left') && $this->countModules('right'))
        $content_width = array('3', '6');
    if(($this->countModules('left') && !$this->countModules('right')) or (!$this->countModules('left') && $this->countModules('right'))) 
        $content_width = array('3', '9');
    if(!$this->countModules('left') && !$this->countModules('right'))
        $content_width = array('0', '12');
		
    $doc->addStyleSheet($this->baseurl.'/templates/'.$this->template.'/css/bootstrap.min.css', $type = 'text/css');
    $doc->addStyleSheet($this->baseurl.'/templates/'.$this->template.'/css/template.css', $type = 'text/css');
    $doc->addStyleSheet($this->baseurl.'/templates/'.$this->template.'/css/custom.css', $type = 'text/css');
	
    $templateColor = $this->params->get("sunshine_color","blue");
    $doc->addStyleSheet($this->baseurl.'/templates/'.$this->template.'/css/template.'. $templateColor .'.css', $type = 'text/css');
    
    $doc->addScriptDeclaration('function offcanvasToggle() {
		var offcanvas = document.getElementById("offcanvas");
		var middle = document.getElementById("sunshine-background-color");
		if ( offcanvas.style.display == "block" ) {
			offcanvas.style.display = "none";
			middle.className = "";
		} else {
			offcanvas.style.display = "block";
			middle.className = "toggle";
		}
	}');

	$googleFont = $this->params->get("googlefont","");
    if(!empty($googleFont)) {
        $doc->addStyleSheet('http://fonts.googleapis.com/css?family='. $this->params->get("googlefont"), $type = 'text/css');
		$doc->addStyleDeclaration('body, p, span, li {font-family:\''. $this->params->get("googlefont").'\';}');
	}
    ?>

</head>

    <body class="<?php echo $view . '-view'; ?>">
    
    <div id="sunshine-background-color">
        
        <div class="container">

            <div id="sunshine-header" class="clearfix">
        
                <?php if( $this->params->get("logo-image")) { ?>
                <div class="logo"><a href="<?php echo JURI::base(); ?>"><img title="<?php echo $app->getCfg('sitename'); ?>" src="<?php echo JURI::base() . $this->params->get("logo-image"); ?>" /></a></div>
                <?php } ?>
                <?php if($this->countModules('social')) : ?>
                    <div id="social"><jdoc:include type="modules" name="social" /></div>
                <?php endif; ?>
                <?php if($this->countModules('search')) : ?>
                <div id="search-container" class="hidden-small">
                    <div id="search" class="form"><jdoc:include type="modules" name="search" xhtml="none" /></div>
                </div>
                <?php endif; ?>
                
            </div>

            <div id="sunshine-container">
            
                <nav class="navigation clearfix">
                
                    <div class="visible-small">
						<a class="sunshine-toggle" href="#" onclick="offcanvasToggle()">
                        	<span class="icon-bar"></span>
                        	<span class="icon-bar"></span>
                        	<span class="icon-bar"></span>
                        </a>
                        <?php if($this->countModules('search')) : ?>
                            <div id="search" class="form"><jdoc:include type="modules" name="search" xhtml="none" /></div>
                        <?php endif; ?>
                    </div>
                
					<div class="hidden-small"><jdoc:include type="modules" name="mainmenu" style="none" /></div>
                </nav>
            
                <div class="clearfix">
                
					<?php if($this->countModules('left')) : ?>
                        <div id="left-sidebar" class="col-md-<?php echo $content_width[0]; ?>">
                        	<jdoc:include type="modules" name="left" style="sidebar" />
                        </div>
					<?php endif; ?>
                    
                    <div class="col-md-<?php echo $content_width[1]; ?>">
                    
                        <?php if($this->countModules('banner')) : ?>
                            <div id="banner"><jdoc:include type="modules" name="banner" /></div>
                        <?php endif; ?>
                        
						<?php if($this->countModules('breadcrumbs')) : ?>
                            <div class="clearfix"><jdoc:include type="modules" name="breadcrumbs" style="none" /></div>
                        <?php endif; ?>
                
                        <div id="content">
							<jdoc:include type="message" />
							<jdoc:include type="component" />
                        </div>
                        
						<?php 
							// Insert Modules
							$modules	= array( 'position-1' => array ('xhtml', 'sunshine-position-1'), 'position-2' => array ('xhtml', 'sunshine-position-2'), 'position-3' => array ('xhtml', 'sunshine-position-3') );
							$count		= count($modules);
							$notVisible = array();
							
							// Test if Module is activated
							foreach($modules AS $key => $value) { if(!$this->countModules($key)) { $count--; $notVisible[] = $key;} }
						
							$sunshine->getModules( $modules, 'col-md', $count, $notVisible);
                        ?>  
                        
                    </div>
                    
					<?php if($this->countModules('right')) : ?>
                        <div id="right-sidebar" class="col-md-<?php echo $content_width[0]; ?>">
                        	<jdoc:include type="modules" name="right" style="sidebar" />
                        </div>
					<?php endif; ?>
                    
                </div>
                
                
            </div>
                
            <div id="sunshine-footer">
                <div class="row-fluid">
						<?php 
							// Insert Modules
							$modules	= array( 'position-4' => array ('xhtml', 'sunshine-position-4'), 'position-5' => array ('xhtml', 'sunshine-position-5'), 'position-5' => array ('xhtml', 'sunshine-position-5'), 'position-6' => array ('xhtml', 'sunshine-position-6'), 'position-7' => array ('xhtml', 'sunshine-position-7') );
							$count		= count($modules);
							$notVisible = array();
							
							// Test if Module is activated
							foreach($modules AS $key => $value) { if(!$this->countModules($key)) { $count--; $notVisible[] = $key; } }
							
							$sunshine->getModules( $modules, 'col-md', $count, $notVisible);
                        ?>

					<div id="copy">&copy; <?php echo JHTML::Date( 'now', 'Y' ); ?> <?php echo $app->getCfg('sitename'); ?></div>
					<?php 
                    /*
                    * License: 
                    * Creative Commons Attribution-Share Alike 3.0 Unported
                    *
                    * WARNING: You are not allowed to remove the link to the copyright owner.
                    */
                    ?>
                    <div id="webdesign-by">Design by <a href="http://www.schefa.com" target="_blank">schefa.com</a></div>
                    
                </div>
			</div>
                
        </div>
        
	</div>
    
    <div id="offcanvas" style="display:none;">
        <div class="offcanvas-bar">
            <jdoc:include type="modules" name="mobile" style="xhtml" />
        </div>
    </div>
    
    </body>
</html>