<?php 
defined( '_JEXEC' ) or die( 'Restricted access' );
								
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >

<head>

<jdoc:include type="head" />

<?php

require("head_includes.php");

$app = JFactory::getApplication();

?>

</head>

<body> 
<div id="background">

<div class="container">

<div class="center">

	<?php if($this->countModules('bannersload or topmenu or logo')) { ?>
	<div id="top">
    
		<?php if($this->countModules('logo')) { ?>
			<div id="topleft">
	        	<div id="logo"><jdoc:include type="modules" name="logo" style="xhtml" /></div>
	        </div>
	    <?php } ?>
        
		<?php if($this->countModules('bannersload or topmenu')) { ?>
			<div id="topright">
            
				<?php if($this->countModules('bannersload')) { ?>
		        <div id="bannerarea">
					<div id="banner"><jdoc:include type="modules" name="bannersload" style="xhtml" /></div>
		        </div>
			    <?php } ?>
		        
				<?php if($this->countModules('topmenu')) { ?>
		        <div id="topmenu"><jdoc:include type="modules" name="topmenu" style="xhtml" /></div>
			    <?php } ?>
            
	        </div>
	    <?php } ?>
        
	</div>
        <div class="clear"></div>
    <?php } ?>
    
	<div id="navigation">
    <div id="navleft">
    <div id="navright">
    	<div id="menubar"><jdoc:include type="modules" name="position-1" style="xhtml" /></div>
    	<div class="clear"></div>
	</div>
    </div>
	</div>
    
    <!-- White Container -->
    <div class="white">
    
    <!-- Header -->
		<?php if( isset($headerimage) ) {?>
	    <div id="header">
	    <div id="headerimage">
        	<img src="<?php echo $this->baseurl; ?>/<?php echo $headerimage; ?>" />
            <?php if($this->countModules('position-2')) { ?>
        	<div class="headerposition"><jdoc:include type="modules" name="position-2" style="xhtml" /></div>
            <?php } ?>
            <div class="clear"></div>
        </div>
	    </div>
	    <?php } ?>
    <!-- Header End -->
        
    <!-- Container Main -->
	    <div id="container_main">
        
        <!-- Position 3 , 4 , 5 , 6 --> 
		<?php if($this->countModules('position-3 or position-4 or position-5 or position-6')) : ?>
	        <div class="user_under_header">
			<?php if($this->countModules('position-3')) : ?>
                <div class="user_<?php echo $user_under_header; ?>">
            	<div class="un_separate">
	                <div class="user_under_header_inside">
	                <jdoc:include type="modules" name="position-3" style="xhtml" />
	                </div>
                </div>
                </div>
            <?php endif; ?>
                
			<?php if($this->countModules('position-4')) : ?>
                <div class="user_<?php echo $user_under_header; ?>">
            	<div class="un_separate">
	                <div class="user_under_header_inside">
	                <jdoc:include type="modules" name="position-4" style="xhtml" />
	                </div>
                </div>
                </div>
            <?php endif; ?>
                
			<?php if($this->countModules('position-5')) : ?>
                <div class="user_<?php echo $user_under_header; ?>">
            	<div class="un_separate">
	                <div class="user_under_header_inside">
	                <jdoc:include type="modules" name="position-5" style="xhtml" />
	                </div>
                </div>
                </div>
            <?php endif; ?>
                
			<?php if($this->countModules('position-6')) : ?>
                <div class="user_<?php echo $user_under_header; ?>">
            	<div class="un_separate">
	                <div class="user_under_header_inside">
	                <jdoc:include type="modules" name="position-6" style="xhtml" />
	                </div>
                </div>
                </div>
            <?php endif; ?>
            <div class="clear"></div>
	        </div>
        <?php endif; ?>
        <!-- Position 3 , 4 , 5 , 6 -- End --> 
        
        
        <div id="maincontent">
        
        	<div id="right_out<?php echo $left . $right; ?>">
            	<div class="un_separate_2">
            
            	<div id="content_out<?php echo $right; ?>">
                
        			<!-- Breadcrumbs --> 
					<?php if($this->countModules('breadcrumbs')) {?>
		            	<div id="pathway"><jdoc:include type="module" name="breadcrumbs" /></div>
		          	<?php } ?>
        			<!-- Breadcrumbs -- End --> 
                    
        			<!-- Position 7 , 8 -- End --> 
	                <?php if($this->countModules('position-7 or position-8')) { ?>
		            <div class="user_content">
                    
					<?php if($this->countModules('position-7')) { ?>
                    <div class="user_<?php echo $user_content; ?>">
                    	<div class="user_inside"><jdoc:include type="modules" name="position-7" style="xhtml" /></div>
                    </div>
                    <?php } ?>
                    
					<?php if($this->countModules('position-8')) { ?>
                    <div class="user_<?php echo $user_content; ?>">
	                    <div class="un_separate">
	                    <div class="user_inside"><jdoc:include type="modules" name="position-8" style="xhtml" /></div>
	                    </div>
                    </div>
                    <?php } ?>
                            
		            </div>
		            <?php } ?>
        			<!-- Position 7 , 8 -- End --> 
                    
		            <div id="content">
			                <div id="content_in"><jdoc:include type="component" /></div>
		            </div>
                    
                    <div class="clear"></div>
                    
		            </div>
                </div>
                
    			<!-- Right -->   
		        <?php if($this->countModules('right')) : ?>
            	<div class="un_separate">
		        <div id="right">
		            <div class="sidebar"><jdoc:include type="modules" name="right" style="xhtml" /></div>
		        </div>
		        </div>
				<?php endif; ?>
    			<!-- Right -- End -->  
                
			</div>
                
    		<!-- Left -->                 
				<?php if($this->countModules('left')) : ?>
		        <div id="left">
            	<div class="un_separate">
		            <div class="sidebar"><jdoc:include type="modules" name="left" style="xhtml" /></div>
		        </div>
		        </div>
				<?php endif; ?>
    		<!-- Left -- End -->     
                 
		</div>
        
        <div class="clear"></div>
                
              
    <!-- Position 9 , 10 , 11 , 12 -->      
		<?php if($this->countModules('position-9 or position-10 or position-11 or position-12')) : ?>
	        <div class="user_under_content">
			<?php if($this->countModules('position-9')) : ?>
                <div class="user_<?php echo $user_under_content; ?>">
            	<div class="un_separate">
	                <div class="user_under_content_inside">
	                <jdoc:include type="modules" name="position-9" style="xhtml" />
	                </div>
                </div>
                </div>
            <?php endif; ?>
                
			<?php if($this->countModules('position-10')) : ?>
                <div class="user_<?php echo $user_under_content; ?>">
            	<div class="un_separate">
	                <div class="user_under_content_inside">
	                <jdoc:include type="modules" name="position-10" style="xhtml" />
	                </div>
                </div>
                </div>
            <?php endif; ?>
                
			<?php if($this->countModules('position-11')) : ?>
                <div class="user_<?php echo $user_under_content; ?>">
            	<div class="un_separate">
	                <div class="user_under_content_inside">
	                <jdoc:include type="modules" name="position-11" style="xhtml" />
	                </div>
                </div>
                </div>
            <?php endif; ?>
                
			<?php if($this->countModules('position-12')) : ?>
                <div class="user_<?php echo $user_under_content; ?>">
            	<div class="un_separate">
	                <div class="user_under_content_inside">
	                <jdoc:include type="modules" name="position-12" style="xhtml" />
	                </div>
                </div>
                </div>
            <?php endif; ?>
            <div class="clear"></div>
	        </div>
        <?php endif; ?>
    <!-- Position 9 , 10 , 11 , 12 -- End -->
            
                
		</div>
    <!-- Container Main -- End -->
	    
	</div>
    <!-- White Container -- End -->
	
    <?php
	// http://creativecommons.org/licenses/by-sa/3.0/deed.en
    echo "<div id=\"bottom_left\"><div id=\"bottom_right\"><div id=\"bottom_content\">Design by <a href=\"http://www.vonfio.de\" style=\"color:#FFFFFF;\">vonfio.de</a></div></div></div>"
	?>
	
	<div id="copyright">&copy; <?php echo JHTML::Date( 'now', 'Y' );  echo " ". $app->getCfg('sitename'); ?><br />
    <jdoc:include type="modules" name="footer" style="xhtml" />
    </div>
    
</div>
<!-- Center -- End -->
</div>
<!-- Container -- End -->
</div>
<!-- Background -- End -->
</body>
</html>