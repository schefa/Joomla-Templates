<?php

	$template_width   					= $this->params->get("templateWidth", "920px");
	$sidebar_width   					= $this->params->get("sidebarWidth", "25");
	$headerimage   					    = $this->params->get("headerimage");
	$headerheight   					= $this->params->get("headerheight");
	$background 						= $this->params->get("background");
	$fontfamily 						= $this->params->get("fontfamily");
	$fontsize 							= $this->params->get("fontsize");
	$fontcolor 							= $this->params->get("fontcolor");
	$linkcolor 							= $this->params->get("linkcolor");
	
	$m800bannersload 					= $this->params->get("m800bannersload");
	$m800headerimage 					= $this->params->get("m800headerimage");
	$m800position3456 					= $this->params->get("m800position3456");
	$m800position78 					= $this->params->get("m800position78");
	$m800position9101112 				= $this->params->get("m800position9101112");
	
	$m600bannersload 					= $this->params->get("m600bannersload");
	$m600headerimage 					= $this->params->get("m600headerimage");
	$m600position3456 					= $this->params->get("m600position3456");
	$m600position78 					= $this->params->get("m600position78");
	$m600position9101112 				= $this->params->get("m600position9101112");
	
	$m500bannersload 					= $this->params->get("m500bannersload");
	$m500headerimage 					= $this->params->get("m500headerimage");
	$m500position3456 					= $this->params->get("m500position3456");
	$m500position78 					= $this->params->get("m500position78");
	$m500position9101112 				= $this->params->get("m500position9101112");
	
	$m300bannersload 					= $this->params->get("m300bannersload");
	$m300headerimage 					= $this->params->get("m300headerimage");
	$m300position3456 					= $this->params->get("m300position3456");
	$m300position78 					= $this->params->get("m300position78");
	$m300position9101112 				= $this->params->get("m300position9101112");


$app 		= JFactory::getApplication();
$doc		= JFactory::getDocument();
$view		= $app->input->getCmd('view', '');

$doc->addStyleSheet($this->baseurl.'/templates/universl/css/bootstrap.min.css', $type = 'text/css');
$doc->addStyleSheet($this->baseurl.'/templates/universl/css/template.css' , $type = 'text/css');
$doc->addStyleSheet($this->baseurl.'/templates/universl/css/menu.css', $type = 'text/css');
?>
<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/<?php echo $this->params->get('colorVariation'); ?>.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/typo.css" type="text/css" />

<link rel="shortcut icon" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template ?>/favicon.ico" />

<?php 
$content1 = $this->countModules("left");
$content2 = $this->countModules("right");

$p0 = $this->countModules("position-0");
$p1 = $this->countModules("position-1");
$p2 = $this->countModules("position-2");
$p3 = $this->countModules("position-3");
$p4 = $this->countModules("position-4");
$p5 = $this->countModules("position-5");
$p6 = $this->countModules("position-6");
$p7 = $this->countModules("position-7");
$p8 = $this->countModules("position-8");
$p9 = $this->countModules("position-9");
$p10 = $this->countModules("position-10");
$p11 = $this->countModules("position-11");
$p12 = $this->countModules("position-12");

$position = array ( $p0, $p1, $p2, $p3, $p4, $p5, $p6, $p7, $p8, $p9, $p10, $p11, $p12, $content1, $content2 );

for ( $x = 0; $x < count($position); $x++ ) {
	if ($position[$x] > 0) { $position[$x] = 1; } else { $position[$x] = 0; }
}

$user_under_header 	= $position[3] + $position[4] +  $position[5] +  $position[6] ;
$user_under_content = $position[9] +  $position[10] +  $position[11] + $position[12] ;
$user_content 		= $position[8] +  $position[9];

if ( $position[13] > 0 ) { $left = "_left"; }
if ( $position[14] > 0 ) { $right = "_right"; }

$left_sidebar_width 	=	$sidebar_width;
$left_sidebar_width_2 	=	100 - $left_sidebar_width;
$right_sidebar_width 	=	$left_sidebar_width * 1.32;
$right_sidebar_width_2 	=	100 - $right_sidebar_width;
?>

<style type="text/css">

	#left { width: <?php echo $left_sidebar_width; ?>%; }
	#right { width: <?php echo $right_sidebar_width; ?>%; }
	#right_out, #right_out_right, #content_out { width: 100%; }
	#right_out_left, #right_out_left_right { width: <?php echo $left_sidebar_width_2; ?>%; }
	#content_out_right { width: <?php echo $right_sidebar_width_2; ?>%; }
	
	.center { max-width: <?php echo $template_width; ?>;  min-width: 220px;}
	body, p, td, tr {
	<?php echo "font-family: ". $fontfamily .";"; ?> 
	<?php echo "font-size: ". $fontsize .";"; ?>
	<?php echo "color: ". $fontcolor .";"; ?>
	}
	#background {  background: <?php echo $background; ?>; }
	a:link, a:visited { color: <?php echo $linkcolor; ?>; }
	#topmenu  a:hover, #topmenu #active_menu, #topmenu li#current a { background-color: <?php echo $linkcolor; ?>; }
	
	<?php if (( $m800bannersload == 1 ) or ( $m800headerimage == 1 ) or ( $m800position3456 == 1 ) or ( $m800position78 == 1 ) or ( $m800position9101112 == 1 )) { ?>
	@media only screen and (max-width: 800px)  {
	<?php if ( $m800bannersload == 1 ) { ?> #bannerarea { display: none; } <?php } ?>
	<?php if ( $m800headerimage == 1 ) { ?> #header { display: none; } <?php } ?>
	<?php if ( $m800position3456 == 1 ) { ?> .user_under_header { display: none; } <?php } ?>
	<?php if ( $m800position78 == 1 ) { ?> .user_content { display: none; } <?php } ?>
	<?php if ( $m800position9101112 == 1 ) { ?> .user_under_content { display: none; } <?php } ?>
	}
	<?php } ?>
	 
	<?php if (( $m600bannersload == 1 ) or ( $m600headerimage == 1 ) or ( $m600position3456 == 1 ) or ( $m600position78 == 1 ) or ( $m600position9101112 == 1 )) { ?>
	@media only screen and (max-width: 600px)  {
	<?php if ( $m600bannersload == 1 ) { ?> #bannerarea { display: none; } <?php } ?>
	<?php if ( $m600headerimage == 1 ) { ?> #header { display: none; } <?php } ?>
	<?php if ( $m600position3456 == 1 ) { ?> .user_under_header { display: none; } <?php } ?>
	<?php if ( $m600position78 == 1 ) { ?> .user_content { display: none; } <?php } ?>
	<?php if ( $m600position9101112 == 1 ) { ?> .user_under_content { display: none; } <?php } ?>
	}
	<?php } ?>
	 
	<?php if (( $m500bannersload == 1 ) or ( $m500headerimage == 1 ) or ( $m500position3456 == 1 ) or ( $m500position78 == 1 ) or ( $m500position9101112 == 1 )) { ?>
	@media only screen and (max-width: 500px)  {
	<?php if ( $m500bannersload == 1 ) { ?> #bannerarea { display: none; } <?php } ?>
	<?php if ( $m500headerimage == 1 ) { ?> #header { display: none; } <?php } ?>
	<?php if ( $m500position3456 == 1 ) { ?> .user_under_header { display: none; } <?php } ?>
	<?php if ( $m500position78 == 1 ) { ?> .user_content { display: none; } <?php } ?>
	<?php if ( $m500position9101112 == 1 ) { ?> .user_under_content { display: none; } <?php } ?>
	}
	<?php } ?>
	 
	<?php if (( $m300bannersload == 1 ) or ( $m300headerimage == 1 ) or ( $m300position3456 == 1 ) or ( $m300position78 == 1 ) or ( $m300position9101112 == 1 )) { ?>
	@media only screen and (max-width: 300px)  {
	<?php if ( $m300bannersload == 1 ) { ?> #bannerarea { display: none; } <?php } ?>
	<?php if ( $m300headerimage == 1 ) { ?> #header { display: none; } <?php } ?>
	<?php if ( $m300position3456 == 1 ) { ?> .user_under_header { display: none; } <?php } ?>
	<?php if ( $m300position78 == 1 ) { ?> .user_content { display: none; } <?php } ?>
	<?php if ( $m300position9101112 == 1 ) { ?> .user_under_content { display: none; } <?php } ?>
	}
	<?php } ?>
	 
</style>

<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/responsive.css" type="text/css" />

<!--[if lte IE 6]>
<style type="text/css">
#content_in {width: 98%;}
</style>
<![endif]-->

<!--[if lte IE 7]>
<style type="text/css">
.user_4 { width: 24.979%; }
</style>
<![endif]-->