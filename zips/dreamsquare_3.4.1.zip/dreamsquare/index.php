<?php 
/**
 *
 * @version             1.0.0
 * @package             Massarbeit
 * @copyright			Copyright (C) 2015 schefa.com. All rights reserved.
 *  
 *             
 */
 
defined('_JEXEC') or die;
							
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" > 

<head>
	
    <jdoc:include type="head" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">

	<link rel="shortcut icon" href="<?php echo $this->baseurl.'/templates/dreamsquare/favicon.ico'; ?>" />

<?php 

$app 	= JFactory::getApplication();
$doc	= JFactory::getDocument();

$logo	= $this->params->get("logo_image");

$doc->addStyleSheet($this->baseurl.'/templates/dreamsquare/css/bootstrap.min.css', $type = 'text/css');
$doc->addStyleSheet($this->baseurl.'/templates/dreamsquare/css/template.css', $type = 'text/css');
$doc->addStyleSheet($this->baseurl.'/templates/dreamsquare/css/custom.css', $type = 'text/css');
$doc->addScriptDeclaration('function dreamsquareToggle() {
	var left = document.getElementById("left_out");
	var middle = document.getElementById("middle");
	if ( left.style.display == "block" ) {
		left.style.display = "none";
		middle.className = "";
	} else {
		left.style.display = "block";
		middle.className = "toggle";
	}
}');
$contentwidth="";
if($this->countModules("left")&&!$this->countModules("right")){ $contentwidth="left";}
if($this->countModules("right")&&!$this->countModules("left")){ $contentwidth="right";}
if($this->countModules("left")&&$this->countModules("right")) { $contentwidth="middle";}

$userwidth = 0;
if($this->countModules("position-1")) { $userwidth += 1; }
if($this->countModules("position-2")) { $userwidth += 1; }
if($this->countModules("position-3")) { $userwidth += 1; }

if ( strlen ($logo) >= 6 ) {
	$logo_url = JURI::base() . $logo;
} else {
	$logo_url = JURI::base() . "templates/dreamsquare/images/logo.png";
}
?>

</head>

<body>
<div id="middle">
    <div class="container">
    <div class="background">
    
    	<div id="left_out" class="dq-left">
        
            <div id="logoarea">
            <div id="logo"><a href="<?php echo $this->baseurl; ?>"><img src="<?php echo $logo_url; ?>" /></a></div>
            </div>
            
        	<?php if($this->countModules('left')) : ?>
            <div id="left">
            <div class="sidebar"><jdoc:include type="modules" name="left" style="xhtml" /></div>
            </div>
            <?php endif; ?>
        </div>
        
    	<div class="dq-right">
            
            <div id="header" class="clearfix">
                <div id="rightheader">
                <div id="top">
                	<a id="dq-toggle" onclick="dreamsquareToggle();" href="#"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a>
                    <div id="sitename"><?php echo $app->getCfg('sitename'); ?></div>
                    <div id="user4"><jdoc:include type="modules" name="search" /></div>
                </div>
                <div id="topmenu_out">
                    <div id="topmenu" class="clearfix"><jdoc:include type="modules" name="mainmenu" /></div>
                </div>
                <div class="clear"></div>
                </div>
            </div>
               
            <div id="maincontent" class="clearfix">
                <div id="content_out<?php echo $contentwidth; ?>">
                
                    <?php if($this->countModules('breadcrumbs')) : ?>
                    <div id="pathway"><jdoc:include type="modules" name="breadcrumbs" /></div>
                    <?php endif; ?>
                    
                    <?php if($this->countModules('banner')) : ?>
                    <div id="bannermodul"><jdoc:include type="modules" name="banner" /></div>
                    <?php endif; ?>
                    <div id="content">
                    <div id="content_in"><jdoc:include type="component" /></div>
                    </div>
                </div>
                <?php if($this->countModules('right')) : ?>
                <div id="right_out_<?php echo $contentwidth; ?>">
                    <div class="sidebar" id="right"><jdoc:include type="modules" name="right" style="xhtml" /></div>
                </div>
                <?php endif; ?>
            </div>
            
        </div>
    </div>
    </div>
    
    <div class="container">
        
        <?php if($this->countModules('position-1') or $this->countModules('position-2') or $this->countModules('position-3')) : ?>
        <div id="user_out">
			<?php if($this->countModules('position-1')) : ?>
            <div class="topmodule_user<?php echo $userwidth; ?>">
                <div class="topmodule_inside"><jdoc:include type="modules" name="position-1" style="xhtml" /></div>
            </div>
            <?php endif; ?>
            <?php if($this->countModules('position-2')) : ?>
            <div class="topmodule_user<?php echo $userwidth; ?>">
                <div class="topmodule_inside"><jdoc:include type="modules" name="position-2" style="xhtml" /></div>
            </div>
            <?php endif; ?>
            <?php if($this->countModules('position-3')) : ?>
            <div class="topmodule_user<?php echo $userwidth; ?>">
                <div class="topmodule_inside"><jdoc:include type="modules" name="position-3" style="xhtml" /></div>
            </div>
            <?php endif; ?>
        </div>
		<?php endif; ?>
        <div class="clear"></div>
        <div id="bottom">
        	<div id="copy">
                &copy; <?php echo date('Y'); ?> <?php echo $app->getCfg('sitename'); ?>
				<?php 
                /*
                * License: 
                * Creative Commons Attribution-Share Alike 3.0 Unported
                *
                * WARNING: You are not allowed to remove the link to the copyright owner.
                */
                ?>
                <br />Design by <a href="http://www.schefa.com" style="color:#999999;">schefa.com</a>
            </div>
        	<div id="othermenu">
				<div id="othermenu_in"><jdoc:include type="modules" name="footer" /></div>
            </div>
        </div>
    </div>
</div>
</body>
</html>