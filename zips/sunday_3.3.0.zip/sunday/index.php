<?php
/**
 *
 * SunDay
 *
 * Default view
 *
 * @version             1.0.0
 * @copyright			Copyright (C) 2012 vonfio.de. All rights reserved.
 *               
 */
 
// No direct access.
defined('_JEXEC') or die; ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >

<head>
<jdoc:include type="head" />

<meta name="viewport" content="width=device-width">
<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />

<?php

// For Sitename
$app 		= JFactory::getApplication();
$doc		= JFactory::getDocument();
$view		= $app->input->getCmd('view', '');

// Param
$linkColor 		= $this->params->get('linkColor');

// if Right Sidebar
if($this->countModules('right')) { $content = "_right"; } else { $content = ""; }

$doc->addStyleSheet($this->baseurl.'/templates/sunday/css/bootstrap.min.css', $type = 'text/css');
$doc->addStyleSheet($this->baseurl.'/templates/sunday/css/template.css', $type = 'text/css');

?>
<style type="text/css">
a:link, a:visited {
	color: <?php echo $linkColor; ?>;
}
</style>

<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/<?php echo $this->params->get('colorVariation'); ?>.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/responsive.css" type="text/css" />

<link rel="shortcut icon" href="<?php echo $this->baseurl; ?>/images/favicon.ico" />

</head>

<body>
<div class="bg"></div>
<div class="marginauto">
    <div id="contain">
    	<div id="header_out">
       	  <div id="header">
           	  <div id="sitetitle"><a href="<?php echo $this->baseurl; ?>"><?php echo $app->getCfg('sitename'); ?></a></div>
                <div id="user3"><jdoc:include type="modules" name="topmenu" style="xhtml" /></div>
          </div>
            <div class="clear"></div>
      </div>
        <div id="maincontent">
            <div id="mid_shadow_left">
            <div id="mid_shadow_right">
                <div id="top_shadow_left">
                <div id="top_shadow_right">
                    <div id="bot_shadow_left">
                    <div id="bot_shadow_right">

<div id="main">

    <div id="maxi">
	<?php if($this->countModules('right')) { ?>
    <div id="right"><jdoc:include type="modules" name="right" style="xhtml" /></div>
    <?php } ?>
    </div>
    
    <div id="left<?php echo $content; ?>">
		<?php if($this->countModules('banner')) { ?>
        <div class="banner"><jdoc:include type="modules" name="banner" style="xhtml" /></div>
        <?php } ?>
        <div id="content">
            <div id="content_in">
                <jdoc:include type="message" />
                <jdoc:include type="component" />
            </div>
        </div>
        <div class="clear"></div>
    </div>
    
    <div id="mini">
	<?php if($this->countModules('right')) { ?>
    <div id="right"><jdoc:include type="modules" name="right" style="xhtml" /></div>
    <?php } ?>
    </div>
    
</div>

                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<div class="bg">
<div id="bottom">&copy; <?php  echo date("Y") . "&nbsp;" . $app->getCfg('sitename'); ?><br />
<div id="copy">Design by <a href="http://www.vonfio.de" target="_blank">vonfio.de</a></div>
<jdoc:include type="modules" name="footer" style="xhtml" /></div>
</div>
</body>
</html>