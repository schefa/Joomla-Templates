<?php 
/**
 *
 * head view
 *
 * @version             1.0.0
 * @package             Joomlike Framework
 * @copyright			Copyright (C) 2012 vonfio.de. All rights reserved.
 *               
 */
 
// No direct access.
defined('_JEXEC') or die;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" > 

<head>
<jdoc:include type="head" />

<?php

	require_once 'templates/nomi/lib/modules.php' ;  

    // Instanz von JDocument erzeugen
    $doc = JFactory::getDocument();
    // jQuery Bibliothek vom Google-CDN hinzufügen
    $doc->addScript('http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js');
    // Hinzufügen unser eigenen Javascript-Datei mit unseren Funktionen
    $doc->addScript('templates/nomi/javascript/jl_hide.js');  
    // jQuery Code zum Initialisieren
    $doc->addScriptDeclaration('jQuery.noConflict();jQuery(document).ready(function(){initMyJS();});');   ?> 

<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="shortcut icon" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template ?>/favicon.ico" />

<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template?>/css/template.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template ?>/css/menu.css" rel="stylesheet" type="text/css" />

<?php if ($this->direction == 'rtl') : ?>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/template_rtl.css" type="text/css" />
<?php endif; ?>

<link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template ?>/css/typo.css" type="text/css" />
<script type="text/javascript">
// Original from Angie Radtke 2009 // 
/* Responsive */

function auf(key) {
	var el = document.id(key);

	if (el.style.display == 'none') {
		el.setStyle('display', 'block');
		el.setProperty('aria-expanded', 'true');

		el.slide('hide').slide('in');
		el.getParent().setProperty('class', 'slide');
		eltern = el.getParent().getParent();
		elternh = eltern.getElement('h3');
		elternh.addClass('high');
		elternbild = eltern.getElement('img');
		// elternbild.focus();
		el.focus();
		elternbild.setProperties( {
			alt : altopen,
			src : bildzu
		});
			
	} else {
		el.setStyle('display', 'none');
		el.setProperty('aria-expanded', 'false');

		el.removeClass('open');
		
		eltern = el.getParent().getParent();
		elternh = eltern.getElement('h3');
		elternh.removeClass('high');
		elternbild = eltern.getElement('img');
		// alert(bildauf);
		elternbild.setProperties( {
			alt : altclose,
			src : bildauf
		});
		elternbild.focus();
	} 
}

/* Suckerfish */

sfHover = function() {
	var sfEls = document.getElementById("navigation").getElementsByTagName("LI");
	for (var i=0; i<sfEls.length; i++) {
		sfEls[i].onmouseover=function() {
			this.className+=" sfhover";
		}
		sfEls[i].onmouseout=function() {
			this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
		}
	}
}
if (window.attachEvent) window.attachEvent("onload", sfHover); 

</script>
<style type="text/css">

	@font-face { font-family: 'Carrois Gothic'; src: url(<?php echo $this->baseurl; ?>/templates/<?php echo $this->template ?>/fonts/CarroisGothic-Regular.ttf);  }
	
	.jl_white { background-color: <?php echo $containercolor; ?>; } 
	#jl_mainmenu {  background-color: <?php echo $navcolor; ?>;}
	.jl_menu li a:hover, .jl_menu li:hover, .jl_menu li:hover ul { background-color: <?php echo $navcolor2; ?>; }
	 
	.jl_menu ul.menu a, .jl_menu ul.menu .separator, #jl_navigation a.toggleMainmenu , #jl_navigation a.toggleSubmenu, .responsive_menu ul li a , .responsive_menu ul li .separator { color: <?php echo $navcolorfont; ?>; }
	.jl_menu ul.menu a:hover, .jl_menu ul.menu .separator:hover { color: <?php echo $navcolorfont2; ?>; }
 	 
#jl_mainmenu, .jl_menu ul.menu a, .jl_menu ul.menu .separator {   
	border: 1px solid <?php echo $navborder; ?>;
}
	 
#jl_submenu, #jl_toolbar, .jl_module div, #jl_content, #jl_breadcrumbs, #jl_contentleft,  #jl_contentright, #jl_contentleft .jl_module div, #jl_contentright .jl_module div, .jl_contenttop, .jl_contentbottom, .jl_contenttop .jl_user_2, .jl_contentbottom .jl_user_2, iframe, .jl_white, #jl_footer_hr{
	border: <?php echo $border; ?>; 
}

	#jl_left { width: <?php echo $left_sidebar_width; ?>%; }
	#jl_right { width: <?php echo $right_sidebar_width; ?>%; }
	#jl_right_out, #jl_right_out_right, #jl_content_out, #jl_content_inset1 { width: 100%; }
	
	#jl_right_out_left, #jl_right_out_left_right { width: <?php echo $left_sidebar_width_2; ?>%; }
	#jl_content_out_right { width: <?php echo $right_sidebar_width_2; ?>%; }

	#jl_contentleft { width: <?php echo $contentleft_sidebar_width; ?>%; }
	#jl_contentright { width: <?php echo $contentright_sidebar_width; ?>%; }
	#jl_content_inset, #jl_content_inset_contentright, #jl_content2_inset, #jl_content_contentleft { width: 100%; }
	
	#jl_content_inset_contentleft_contentright, #jl_content_inset_contentleft{ width: <?php echo $contentleft_sidebar_width_2; ?>%; }
	#jl_content2_inset_contentright { width: <?php echo $contentright_sidebar_width_2; ?>%; }
	
	.jl_separate_right, .jl_white { padding-right: <?php echo $cellpadding; ?>; }.jl_un_separate, .jl_separate_left, .jl_white { padding-left: <?php echo $cellpadding; ?>; } #jl_navigation, #jl_header,  .jl_module div, .jl_content2_inset, #jl_contentright, #jl_contentleft, .jl_white { margin-bottom: <?php echo $cellpadding; ?>; } .jl_white{ padding-top: <?php echo $cellpadding; ?>; }
	

	.jl_center { max-width: <?php echo $template_width; ?>;  min-width: 150px;}
	body, p, td, tr {
	<?php echo "font-family: ". $fontfamily .";"; ?> 
	<?php echo "font-size: ". $fontsize .";"; ?>
	<?php echo "color: ". $fontcolor .";"; ?>
	}
	#jl_copyright a {	<?php echo "color: ". $fontcolor .";"; ?>	} 
	
	#jl_background, body { background-image: url(<?php echo $this->baseurl; ?>/<?php echo $background; ?>); background-color: <?php echo $backgroundcolor; ?>; }
	 
	a:link, a:visited, ul.menu span.separator { color: <?php echo $linkcolor; ?>; } 
	
</style>

<link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template ?>/css/responsive.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template ?>/css/custom.css" type="text/css" />

 
</head>

<?php if(count($app->getMessageQueue())) : ?>
<jdoc:include type="message" />
<?php endif; ?>